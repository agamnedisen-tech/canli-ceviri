package com.example.ceviri

import android.Manifest
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var keyBox: EditText
    private lateinit var modelBox: EditText
    private var selected = 0

    private val ids = arrayOf("gemini", "claude", "openai")
    private val names = arrayOf("Google Gemini (ücretsiz katmanı var)", "Claude (Anthropic)", "ChatGPT (OpenAI)")
    private val defModels = arrayOf("gemini-3.5-flash-lite", "claude-haiku-5-5", "gpt-4o-mini")
    private val keyUrls = arrayOf(
        "https://aistudio.google.com/apikey",
        "https://console.anthropic.com/settings/keys",
        "https://platform.openai.com/api-keys"
    )

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, CaptionService::class.java)
                    .putExtra("code", r.resultCode)
                    .putExtra("data", data)
                ContextCompat.startForegroundService(this, i)
            }
        }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { begin() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("ceviri", MODE_PRIVATE)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        fun label(t: String, size: Float = 15f, bold: Boolean = false) = TextView(this).apply {
            text = t
            textSize = size
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, pad / 2, 0, pad / 4)
        }

        layout.addView(label("Canlı Altyazı Çevirisi", 22f, true))
        layout.addView(label(
            "YouTube'daki İngilizce altyazıyı anında Türkçeye çevirir.\n\n" +
            "1. YouTube'da videoyu aç, CC simgesinden İngilizce altyazıyı aç.\n" +
            "2. Buraya dönüp Başlat'a bas, istenen izinleri ver.\n" +
            "3. Çeviri dikeyde videonun altında, yatay tam ekranda ekranın üstünde görünür."
        ))
        layout.addView(Button(this).apply {
            text = "Başlat"
            setOnClickListener {
                prefs.edit()
                    .putString("key", keyBox.text.toString().trim())
                    .putString("provider", ids[selected])
                    .putString("model", modelBox.text.toString().trim().ifEmpty { defModels[selected] })
                    .apply()
                permLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
            }
        })
        layout.addView(Button(this).apply {
            text = "Durdur"
            setOnClickListener {
                startService(Intent(this@MainActivity, CaptionService::class.java).setAction("STOP"))
            }
        })
        layout.addView(label(
            "İlk açılışta \"Diğer uygulamaların üzerinde göster\" iznini vermen gerekir; izni verip " +
            "geri dönünce tekrar Başlat'a bas.\n\n" +
            "\"Uygulamanın erişimi reddedildi\" uyarısı çıkarsa: Ayarlar > Uygulamalar > bu uygulama > " +
            "sağ üstteki ⋮ > Kısıtlı ayarlara izin ver.",
            13f
        ))

        // Gelişmiş bölüm (isteğe bağlı)
        val advanced = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        advanced.addView(label(
            "İstersen kendi yapay zekâ hesabınla daha doğal çeviri alabilirsin. Anahtar girmezsen " +
            "cihaz içi çeviri kullanılır. Anahtar girersen altyazı metni seçtiğin sağlayıcıya gönderilir.\n\n" +
            "Not: Claude ve ChatGPT uygulama abonelikleri API anahtarı içermez, API ayrı ücretlendirilir. " +
            "Gemini'nin ücretsiz katmanı vardır.",
            13f
        ))
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        advanced.addView(spinner)
        advanced.addView(Button(this).apply {
            text = "Anahtar al (tarayıcıda açılır)"
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(keyUrls[selected])))
            }
        })
        keyBox = EditText(this).apply {
            hint = "API anahtarı"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        advanced.addView(keyBox)
        advanced.addView(label("Model adı (sağlayıcı modeli değiştirirse buradan güncelle):", 13f))
        modelBox = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            setText(prefs.getString("model", ""))
        }
        advanced.addView(modelBox)

        selected = ids.indexOf(prefs.getString("provider", "gemini")).coerceAtLeast(0)
        spinner.setSelection(selected)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                selected = pos
                val cur = modelBox.text.toString().trim()
                if (cur.isEmpty() || defModels.contains(cur)) modelBox.setText(defModels[pos])
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        layout.addView(Button(this).apply {
            text = "Gelişmiş (isteğe bağlı) ▾"
            setOnClickListener {
                advanced.visibility = if (advanced.visibility == View.GONE) View.VISIBLE else View.GONE
            }
        })
        layout.addView(advanced)

        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun begin() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "İzni ver, sonra geri dönüp tekrar Başlat'a bas", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}

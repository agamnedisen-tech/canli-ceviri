package com.example.ceviri

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.core.content.IntentCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.*
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File

class CaptionService : Service() {

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val ui = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    private var translator: Translator? = null
    private var overlay: TextView? = null
    private lateinit var wm: WindowManager
    private val clearRunnable = Runnable { overlay?.text = "" }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == "STOP") { stopSelf(); return START_NOT_STICKY }

        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addOverlay()

        val code = intent.getIntExtra("code", 0)
        val data = IntentCompat.getParcelableExtra(intent, "data", Intent::class.java)!!
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, ui)
        }

        show("Çeviri modeli hazırlanıyor…")
        translator = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.TURKISH)
                .build()
        )
        translator!!.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { startRecognition() }
            .addOnFailureListener { show("Çeviri modeli indirilemedi (internet gerekli)") }

        return START_NOT_STICKY
    }

    private fun startRecognition() {
        scope.launch {
            val modelDir = File(filesDir, "model-en")
            if (!modelDir.exists()) copyAssets("model-en", modelDir)
            val recognizer = Recognizer(Model(modelDir.absolutePath), 16000f)

            val config = AudioPlaybackCaptureConfiguration.Builder(projection!!)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(16000)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()
            record = AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes(32000)
                .setAudioPlaybackCaptureConfig(config)
                .build()
            record!!.startRecording()
            show("Dinleniyor…")

            val buf = ByteArray(4096)
            var lastPartial = ""
            var lastTranslate = 0L
            while (isActive) {
                val n = record!!.read(buf, 0, buf.size)
                if (n <= 0) continue
                if (recognizer.acceptWaveForm(buf, n)) {
                    val text = JSONObject(recognizer.result).optString("text")
                    if (text.isNotBlank()) translate(text)
                    lastPartial = ""
                } else {
                    val partial = JSONObject(recognizer.partialResult).optString("partial")
                    val now = System.currentTimeMillis()
                    // Kısmi sonuçları en fazla ~0.8 sn'de bir çevir
                    if (partial.isNotBlank() && partial != lastPartial && now - lastTranslate > 800) {
                        lastPartial = partial
                        lastTranslate = now
                        translate(partial)
                    }
                }
            }
        }
    }

    private fun translate(text: String) {
        translator?.translate(text)?.addOnSuccessListener { show(it) }
    }

    private fun show(text: String) {
        ui.post {
            overlay?.text = text
            ui.removeCallbacks(clearRunnable)
            ui.postDelayed(clearRunnable, 5000)
        }
    }

    private fun addOverlay() {
        overlay = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            gravity = Gravity.CENTER
            setBackgroundColor(0xAA000000.toInt())
            setPadding(24, 12, 24, 12)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM; y = 160 }
        wm.addView(overlay, lp)
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ceviri", "Canlı çeviri", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, "ceviri")
            .setContentTitle("Canlı altyazı çalışıyor")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun copyAssets(path: String, dest: File) {
        val list = assets.list(path) ?: emptyArray()
        if (list.isEmpty()) {
            dest.parentFile?.mkdirs()
            assets.open(path).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dest.mkdirs()
            list.forEach { copyAssets("$path/$it", File(dest, it)) }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        record?.run { try { stop() } catch (_: Exception) {}; release() }
        projection?.stop()
        translator?.close()
        overlay?.let { wm.removeView(it) }
        super.onDestroy()
    }
}

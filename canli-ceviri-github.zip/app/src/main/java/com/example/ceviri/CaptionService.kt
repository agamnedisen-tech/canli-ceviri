package com.example.ceviri

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.core.content.IntentCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Ekranı ~1.4 kare/sn yakalar, YouTube altyazı bölgesini OCR ile okur,
 * Türkçeye çevirir ve videonun dışında bir yüzen kutuda gösterir.
 */
class CaptionService : Service() {

    private val ui = Handler(Looper.getMainLooper())
    private val bgThread = HandlerThread("capture").apply { start() }
    private val bg = Handler(bgThread.looper)

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var translator: Translator? = null
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private var overlay: TextView? = null
    private var overlayLp: WindowManager.LayoutParams? = null
    private lateinit var wm: WindowManager

    private var capW = 0
    private var capH = 0
    private var lastRun = 0L
    @Volatile private var busy = false
    private var lastLand: Boolean? = null

    private var en = ""
    private var tr = ""
    private var lastNorm = ""
    private var seq = 0

    // Kullanıcının kendi yapay zekâsı (Gemini / Claude / OpenAI)
    private var apiKey = ""
    private var keyBad = false
    private var warned = false
    private var llmBusy = false
    private var pending: String? = null
    private var lastLlm = 0L
    private var timerSet = false
    @Volatile private var backoffUntil = 0L
    private var provider = "gemini"
    private var model = ""
    private val minIntervalMs = 3500L
    private val history = ArrayDeque<String>()
    private val net = Executors.newSingleThreadExecutor()

    private val clearRunnable = Runnable { en = ""; tr = ""; lastNorm = ""; overlay?.text = "" }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY

        val prefs = getSharedPreferences("ceviri", MODE_PRIVATE)
        apiKey = prefs.getString("key", "")?.trim() ?: ""
        provider = prefs.getString("provider", "gemini") ?: "gemini"
        model = prefs.getString("model", "")?.trim() ?: ""
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addOverlay()

        val code = intent.getIntExtra("code", 0)
        val data = IntentCompat.getParcelableExtra(intent, "data", Intent::class.java)!!
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, ui)
        }

        status("Çeviri modeli hazırlanıyor…")
        translator = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.TURKISH)
                .build()
        )
        translator!!.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                status("Hazır. YouTube'da İngilizce altyazıyı (CC) aç.")
                val (w, h, _) = screenSize()
                setupReader(w, h)
            }
            .addOnFailureListener { status("Çeviri modeli indirilemedi (internet gerekli)") }

        return START_NOT_STICKY
    }

    // ---------- Ekran yakalama ----------

    private fun screenSize(): Triple<Int, Int, Int> {
        val dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        dm.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m)
        return Triple(m.widthPixels, m.heightPixels, m.densityDpi)
    }

    private fun setupReader(w: Int, h: Int) {
        val dpi = screenSize().third
        val newReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        newReader.setOnImageAvailableListener({ onFrame(it) }, bg)
        if (vd == null) {
            vd = projection!!.createVirtualDisplay(
                "cap", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                newReader.surface, null, null
            )
        } else {
            vd!!.resize(w, h, dpi)
            vd!!.surface = newReader.surface
        }
        val old = reader
        reader = newReader
        capW = w
        capH = h
        try { old?.close() } catch (_: Exception) {}
    }

    private fun statusBarHeight(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun onFrame(rd: ImageReader) {
        val image = try { rd.acquireLatestImage() } catch (_: Exception) { null } ?: return
        try {
            val now = SystemClock.elapsedRealtime()
            if (busy || now - lastRun < 700) return

            val (sw, sh, _) = screenSize()
            if (sw != capW || sh != capH) { ui.post { setupReader(sw, sh) }; return }
            lastRun = now

            val w = image.width
            val h = image.height
            val land = w > h
            val sb = statusBarHeight()
            val videoH = (w * 9f / 16f).toInt()

            // Altyazı bölgesi
            val top: Int
            val bottom: Int
            if (land) {
                top = (h * 0.58f).toInt()
                bottom = (h * 0.90f).toInt()
            } else {
                top = sb + (videoH * 0.50f).toInt()
                bottom = (sb + videoH).coerceAtMost(h)
            }
            if (bottom - top < 20) return

            val plane = image.planes[0]
            val pad = plane.rowStride - plane.pixelStride * w
            val full = Bitmap.createBitmap(w + pad / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            val crop = Bitmap.createBitmap(full, 0, top, w, bottom - top)
            full.recycle()

            placeOverlay(land, sb + videoH)

            busy = true
            recognizer.process(InputImage.fromBitmap(crop, 0))
                .addOnSuccessListener { handleText(it.text) }
                .addOnCompleteListener { busy = false; crop.recycle() }
        } catch (_: Exception) {
            busy = false
        } finally {
            image.close()
        }
    }

    // ---------- Metin işleme ve çeviri ----------

    private fun handleText(raw: String) {
        val text = raw.replace("\n", " ").replace(Regex("\\s+"), " ").trim()
        val norm = text.lowercase().filter { it.isLetter() }
        if (norm.length < 4) return
        if (norm == lastNorm) { renew(); return }
        lastNorm = norm
        en = text
        render()
        seq++
        if (apiKey.isNotBlank() && !keyBad) askLlm(text) else mlTranslate(text)
    }

    private fun mlTranslate(text: String) {
        val id = seq
        translator?.translate(text)?.addOnSuccessListener {
            if (id == seq) { tr = it; render() }
        }
    }

    /** Aynı anda tek istek, istekler arası en az 3.5 sn (limitlere takılmamak için); en yeni metin beklemeye alınır. */
    private fun askLlm(text: String) {
        val now = SystemClock.elapsedRealtime()
        if (now < backoffUntil) { mlTranslate(text); return }
        val wait = minIntervalMs - (now - lastLlm)
        if (llmBusy || wait > 0) {
            pending = text
            if (!timerSet) {
                timerSet = true
                ui.postDelayed({
                    timerSet = false
                    pending?.let { pending = null; askLlm(it) }
                }, maxOf(wait, 500L))
            }
            return
        }
        llmBusy = true
        lastLlm = now
        val ctx = history.joinToString("\n")
        net.execute {
            var result: String? = null
            try {
                result = callLlm(text, ctx)
            } catch (e: IllegalStateException) {
                keyBad = true
            } catch (_: Exception) {
            }
            ui.post {
                llmBusy = false
                if (result != null) {
                    tr = result
                    history.addLast(text)
                    while (history.size > 3) history.removeFirst()
                    render()
                } else {
                    if (keyBad && !warned) {
                        warned = true
                        status("Yapay zekâ anahtarı/model hatalı, yerleşik çeviri kullanılıyor")
                    }
                    mlTranslate(text)
                }
                pending?.let { pending = null; askLlm(it) }
            }
        }
    }

    private fun callLlm(text: String, ctx: String): String? {
        val system = "Sen canlı YouTube altyazı çevirmenisin. Kullanıcı, ekrandan OCR ile okunmuş " +
            "İngilizce altyazı metnini verir. Metin cümlenin ortasında başlayıp bitebilir, kelimeler " +
            "yanlış okunmuş veya kopuk olabilir. Önceki altyazıları bağlam olarak kullan, açıkça " +
            "yanlış okunmuş kelimeleri bağlama göre düzelt ve metni anlamlı, doğal, akıcı Türkçeye çevir. " +
            "Yalnızca Türkçe çeviriyi yaz, açıklama ya da tırnak ekleme."
        val user = (if (ctx.isNotBlank()) "Önceki altyazılar (bağlam):\n$ctx\n\n" else "") +
            "Çevrilecek altyazı:\n$text"

        val urlStr: String
        val body: JSONObject
        val headers = mutableMapOf("content-type" to "application/json")
        when (provider) {
            "claude" -> {
                urlStr = "https://api.anthropic.com/v1/messages"
                headers["x-api-key"] = apiKey
                headers["anthropic-version"] = "2023-06-01"
                body = JSONObject().put("model", model).put("max_tokens", 300).put("system", system)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
            }
            "openai" -> {
                urlStr = "https://api.openai.com/v1/chat/completions"
                headers["authorization"] = "Bearer $apiKey"
                body = JSONObject().put("model", model).put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", user)))
            }
            else -> {
                urlStr = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
                headers["x-goog-api-key"] = apiKey
                body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                    .put("contents", JSONArray().put(
                        JSONObject().put("role", "user")
                            .put("parts", JSONArray().put(JSONObject().put("text", user)))
                    ))
            }
        }

        val conn = URL(urlStr).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 5000
            conn.readTimeout = 10000
            conn.doOutput = true
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            if (code == 400 || code == 401 || code == 403 || code == 404) throw IllegalStateException("anahtar/model")
            if (code == 429) { backoffUntil = SystemClock.elapsedRealtime() + 20000; return null }
            if (code != 200) return null
            val json = JSONObject(conn.inputStream.bufferedReader().readText())
            val sb = StringBuilder()
            when (provider) {
                "claude" -> {
                    val arr = json.getJSONArray("content")
                    for (i in 0 until arr.length()) sb.append(arr.getJSONObject(i).optString("text"))
                }
                "openai" -> sb.append(
                    json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
                )
                else -> {
                    val parts = json.getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts")
                    for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                }
            }
            return sb.toString().trim().ifBlank { null }
        } finally {
            conn.disconnect()
        }
    }

    // ---------- Gösterim ----------

    private fun status(msg: String) { en = ""; tr = msg; render() }

    private fun renew() {
        ui.removeCallbacks(clearRunnable)
        ui.postDelayed(clearRunnable, 6000)
    }

    private fun render() {
        ui.post {
            val sb = SpannableStringBuilder()
            if (en.isNotBlank()) {
                val st = sb.length
                sb.append(en)
                sb.setSpan(ForegroundColorSpan(0xFFBBBBBB.toInt()), st, sb.length, 0)
                sb.setSpan(RelativeSizeSpan(0.75f), st, sb.length, 0)
                sb.append("\n")
            }
            sb.append(tr)
            overlay?.text = sb
            renew()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun addOverlay() {
        overlay = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            gravity = Gravity.CENTER
            setBackgroundColor(0xCC000000.toInt())
            setPadding(24, 12, 24, 12)
        }
        overlayLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP; y = dp(24) }
        wm.addView(overlay, overlayLp)
    }

    /** Dikeyde videonun hemen altına, yatayda ekranın üstüne koyar (OCR bölgesinin dışı). */
    private fun placeOverlay(land: Boolean, videoBottom: Int) {
        if (lastLand == land) return
        lastLand = land
        ui.post {
            val lp = overlayLp ?: return@post
            lp.y = if (land) dp(16) else videoBottom + dp(8)
            overlay?.let { wm.updateViewLayout(it, lp) }
        }
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ceviri", "Canlı çeviri", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, "ceviri")
            .setContentTitle("Altyazı çevirisi çalışıyor")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        try { vd?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        projection?.stop()
        recognizer.close()
        translator?.close()
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        net.shutdownNow()
        bgThread.quitSafely()
        super.onDestroy()
    }
}

# Canlı Çeviri Altyazı (İngilizce -> Türkçe)

1. Bu klasörün tüm içeriğini (gizli .github klasörü dahil) yeni bir GitHub deposuna yükle.
2. Depoda Actions sekmesi > "APK derle" çalışır (yoksa "Run workflow").
3. Bitince çalıştırmanın sayfasında Artifacts > canli-ceviri-apk indir, zip'ten app-debug.apk çıkar.
4. Telefona kur (bilinmeyen kaynaklara izin gerekir).

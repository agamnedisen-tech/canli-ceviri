package com.example.ceviri

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.IntentCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Ekranı yakalar, YouTube altyazısını (beyaz yazı / koyu kutu) OCR ile okur, her kelimeyi bir kez
 * alıp cümle parçası halinde Türkçeye çevirir. Çeviri okuma süresi kadar görünür, sonra kaybolur.
 */
class CaptionService : Service() {

    // ---- yakalama ----
    private val ui = Handler(Looper.getMainLooper())
    private val bgThread = HandlerThread("capture").apply { start() }
    private val bg = Handler(bgThread.looper)
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var translator: Translator? = null
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private lateinit var wm: WindowManager
    private var capW = 0
    private var capH = 0
    private var lastRun = 0L
    @Volatile private var busy = false
    private var lastLand: Boolean? = null

    // ---- görünüm ----
    private var overlay: TextView? = null
    private var overlayLp: WindowManager.LayoutParams? = null
    private var controls: LinearLayout? = null
    private var controlsLp: WindowManager.LayoutParams? = null
    private var pauseBtn: TextView? = null
    private var enBtn: TextView? = null
    @Volatile private var shown = false
    private var showEn = false

    // ---- altyazı akışı ----
    private val assembler = Assembler()
    private val chunks = ArrayList<Chunk>()
    private val recentKeys = ArrayDeque<String>()
    private var viewChunk: Chunk? = null
    private var live = true
    @Volatile private var paused = false

    // ---- kullanıcının kendi yapay zekâsı ----
    private var apiKey = ""
    private var provider = "gemini"
    private var model = ""
    private var keyBad = false
    private var warned = false
    private var llmBusy = false
    private var lastLlm = 0L
    private var timerSet = false
    @Volatile private var backoffUntil = 0L
    private val minIntervalMs = 3500L
    private val queue = ArrayDeque<Chunk>()
    private val net = Executors.newSingleThreadExecutor()

    private val hideRunnable = Runnable { overlay?.visibility = View.GONE; shown = false }
    private val ticker = object : Runnable {
        override fun run() {
            if (!paused) maybeFlush()
            ui.postDelayed(this, 400)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY

        val prefs = getSharedPreferences("ceviri", MODE_PRIVATE)
        apiKey = prefs.getString("key", "")?.trim() ?: ""
        provider = prefs.getString("provider", "gemini") ?: "gemini"
        model = prefs.getString("model", "")?.trim() ?: ""
        showEn = prefs.getBoolean("showEn", false)

        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addOverlay()
        addControls()
        val (sw0, sh0, _) = screenSize()
        placeOverlay(sw0 > sh0, statusBarHeight() + (sw0 * 9f / 16f).toInt(), sw0)

        val code = intent.getIntExtra("code", 0)
        val data = IntentCompat.getParcelableExtra(intent, "data", Intent::class.java)!!
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, ui)
        }

        status("Çeviri modeli hazırlanıyor…")
        translator = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.TURKISH)
                .build()
        )
        translator!!.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                status("Hazır. YouTube'da İngilizce altyazıyı (CC) aç.")
                val (w, h, _) = screenSize()
                setupReader(w, h)
                ui.post(ticker)
            }
            .addOnFailureListener { status("Çeviri modeli indirilemedi (internet gerekli)") }

        return START_NOT_STICKY
    }

    // =================== Ekran yakalama ===================

    private fun screenSize(): Triple<Int, Int, Int> {
        val dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        dm.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m)
        return Triple(m.widthPixels, m.heightPixels, m.densityDpi)
    }

    private fun setupReader(w: Int, h: Int) {
        val dpi = screenSize().third
        val newReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        newReader.setOnImageAvailableListener({ onFrame(it) }, bg)
        if (vd == null) {
            vd = projection!!.createVirtualDisplay(
                "cap", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                newReader.surface, null, null
            )
        } else {
            vd!!.resize(w, h, dpi)
            vd!!.surface = newReader.surface
        }
        val old = reader
        reader = newReader
        capW = w
        capH = h
        try { old?.close() } catch (_: Exception) {}
    }

    private fun statusBarHeight(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun onFrame(rd: ImageReader) {
        val image = try { rd.acquireLatestImage() } catch (_: Exception) { null } ?: return
        try {
            if (paused) return
            val now = SystemClock.elapsedRealtime()
            if (busy || now - lastRun < 700) return

            val (sw, sh, _) = screenSize()
            if (sw != capW || sh != capH) { ui.post { setupReader(sw, sh) }; return }
            lastRun = now

            val w = image.width
            val h = image.height
            val land = w > h
            val sb = statusBarHeight()
            val videoH = (w * 9f / 16f).toInt()

            val top: Int
            val bottom: Int
            if (land) {
                top = (h * 0.58f).toInt()
                bottom = (h * 0.90f).toInt()
            } else {
                top = sb + (videoH * 0.50f).toInt()
                bottom = (sb + videoH).coerceAtMost(h)
            }
            if (bottom - top < 20) return

            val plane = image.planes[0]
            val pad = plane.rowStride - plane.pixelStride * w
            val full = Bitmap.createBitmap(w + pad / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            val crop = Bitmap.createBitmap(full, 0, top, w, bottom - top)
            full.recycle()

            placeOverlay(land, sb + videoH, w)

            busy = true
            recognizer.process(InputImage.fromBitmap(crop, 0))
                .addOnSuccessListener { handleOcr(it, crop) }
                .addOnCompleteListener { busy = false; crop.recycle() }
        } catch (_: Exception) {
            busy = false
        } finally {
            image.close()
        }
    }

    // =================== Altyazıyı ayıklama ===================

    private fun handleOcr(res: Text, crop: Bitmap) {
        if (paused) return
        val text = captionLines(res, crop).joinToString(" ")
        if (text.isBlank()) return
        val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (assembler.feed(words, SystemClock.elapsedRealtime())) maybeFlush()
    }

    /** Yalnızca altyazı gibi görünen satırları alır: ortalı, çoğu harf, koyu zemin üzerinde açık yazı. */
    private fun captionLines(res: Text, bmp: Bitmap): List<String> {
        val w = bmp.width
        val found = ArrayList<Pair<Int, String>>()
        for (block in res.textBlocks) for (line in block.lines) {
            val box = line.boundingBox ?: continue
            val t = line.text.trim()
            val letters = t.count { it.isLetter() }
            if (letters < 2 || letters * 10 < t.length * 6) continue          // sayı/saat/skor gibi satırları ele
            if (kotlin.math.abs(box.centerX() - w / 2) > w * 0.22f) continue  // altyazı ortalıdır
            if (!looksLikeCaption(bmp, box)) continue                          // oyun/video içi yazıları ele
            found.add(box.top to t)
        }
        return found.sortedBy { it.first }.map { it.second }
    }

    private fun looksLikeCaption(bmp: Bitmap, box: Rect): Boolean {
        val pad = 8
        val x0 = (box.left - pad).coerceAtLeast(0)
        val y0 = (box.top - pad).coerceAtLeast(0)
        val x1 = (box.right + pad).coerceAtMost(bmp.width)
        val y1 = (box.bottom + pad).coerceAtMost(bmp.height)
        val rw = x1 - x0
        val rh = y1 - y0
        if (rw <= 0 || rh <= 0) return false
        val px = IntArray(rw * rh)
        bmp.getPixels(px, 0, rw, x0, y0, rw, rh)
        var ringSum = 0L; var ringN = 0; var bright = 0; var inN = 0
        for (yy in 0 until rh step 2) for (xx in 0 until rw step 2) {
            val c = px[yy * rw + xx]
            val lum = (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000
            val gx = x0 + xx
            val gy = y0 + yy
            val inside = gx >= box.left && gx < box.right && gy >= box.top && gy < box.bottom
            if (inside) { inN++; if (lum > 185) bright++ } else { ringN++; ringSum += lum }
        }
        if (ringN == 0 || inN == 0) return false
        return ringSum / ringN < 110 && bright * 100 >= inN * 4
    }

    // =================== Parça oluşturma ve çeviri ===================

    private fun maybeFlush() {
        if (!assembler.shouldFlush(SystemClock.elapsedRealtime())) return
        val en = assembler.take()
        if (en.count { it.isLetter() } < 3) return
        val key = en.lowercase().filter { it.isLetterOrDigit() }
        if (recentKeys.contains(key)) return            // aynı yazı ikinci kez çevrilmesin
        recentKeys.addLast(key)
        while (recentKeys.size > 12) recentKeys.removeFirst()

        val c = Chunk(en)
        chunks.add(c)
        while (chunks.size > 40) chunks.removeAt(0)
        if (apiKey.isNotBlank() && !keyBad) { queue.addLast(c); pumpLlm() } else mlTranslate(c)
    }

    private fun onTranslated(c: Chunk) {
        if (paused || c.tr.isBlank()) return
        if (live) showChunk(c)
    }

    // ---- yerleşik çeviri (ML Kit) ----

    /** Kısaltma ve rakamlı kelimeleri (FIFA, FC25, 4K...) çeviriden korur. */
    private fun protect(text: String): Pair<String, Map<String, String>> {
        val map = LinkedHashMap<String, String>()
        var idx = 0
        var words = 0
        val out = Regex("\\S+").replace(text) { m ->
            words++
            val tok = m.value
            val core = tok.trim { !it.isLetterOrDigit() }
            val upperAbbr = core.length >= 2 && core.any { it.isLetter() } &&
                core.all { it.isUpperCase() || it.isDigit() }
            val mixedDigit = core.any { it.isDigit() } && core.any { it.isLetter() }
            if ((upperAbbr || mixedDigit) && idx < 20) {
                val key = "Zq" + ('a' + idx) + "q"
                idx++
                map[key] = core
                tok.replace(core, key)
            } else tok
        }
        return if (map.size * 2 > words) text to emptyMap() else out to map
    }

    private fun mlTranslate(c: Chunk) {
        val (prot, map) = protect(c.en)
        translator?.translate(prot)?.addOnSuccessListener {
            var r = it
            for ((k, v) in map) r = r.replace(Regex(Regex.escape(k), RegexOption.IGNORE_CASE), v)
            c.tr = r
            onTranslated(c)
        }
    }

    // ---- kullanıcının kendi yapay zekâsı ----

    private fun pumpLlm() {
        if (queue.isEmpty()) return
        val now = SystemClock.elapsedRealtime()
        if (now < backoffUntil) { while (queue.isNotEmpty()) mlTranslate(queue.removeFirst()); return }
        val wait = minIntervalMs - (now - lastLlm)
        if (llmBusy || wait > 0) {
            if (!llmBusy && !timerSet) {
                timerSet = true
                ui.postDelayed({ timerSet = false; pumpLlm() }, maxOf(wait, 300L))
            }
            return
        }
        // Bekleyen parçaları tek istekte birleştir (hiçbiri atlanmaz)
        val first = queue.removeFirst()
        while (queue.isNotEmpty()) {
            val o = queue.removeFirst()
            first.en += " " + o.en
            chunks.remove(o)
        }
        llmBusy = true
        lastLlm = now

        val idx = chunks.indexOf(first)
        val prev = if (idx > 0) chunks.subList(maxOf(0, idx - 2), idx).filter { it.tr.isNotBlank() } else emptyList()
        val ctx = prev.joinToString("\n") { "EN: ${it.en}\nTR: ${it.tr}" }
        val text = first.en

        net.execute {
            var result: String? = null
            try {
                result = callLlm(text, ctx)
            } catch (e: IllegalStateException) {
                keyBad = true
            } catch (_: Exception) {
            }
            ui.post {
                llmBusy = false
                if (result != null) {
                    first.tr = result
                    onTranslated(first)
                } else {
                    if (keyBad && !warned) {
                        warned = true
                        status("Yapay zekâ anahtarı/model hatalı, yerleşik çeviri kullanılıyor")
                    }
                    mlTranslate(first)
                }
                pumpLlm()
            }
        }
    }

    private fun callLlm(text: String, ctx: String): String? {
        val system = "Sen canlı YouTube altyazı çevirmenisin. Kullanıcı, ekrandan OCR ile okunmuş " +
            "İngilizce altyazı parçasını verir. Kurallar: " +
            "1) Cümle bütünlüğünü ve anlamı esas al; kopuk, yarım ya da yanlış okunmuş kelimeleri " +
            "bağlama göre düzelterek akıcı, doğal Türkçe yaz. " +
            "2) Özel isimleri, marka, oyun ve oyuncu adlarını, kısaltmaları ve Türkçede yerleşik karşılığı " +
            "olmayan terimleri ÇEVİRME, olduğu gibi bırak. " +
            "3) Metinde olmayan hiçbir sayı, tarih, saat ya da kelime ekleme. " +
            "4) Altyazı dışı görünen yazıları (menü, skor, saat, düğme adı) yok say. " +
            "Yalnızca Türkçe çeviriyi yaz; açıklama, tırnak ya da not ekleme."
        val user = (if (ctx.isNotBlank())
            "Önceki altyazılar ve çevirileri (yalnızca bağlam, tekrar çevirme):\n$ctx\n\n" else "") +
            "Çevrilecek altyazı:\n$text"

        val urlStr: String
        val body: JSONObject
        val headers = mutableMapOf("content-type" to "application/json")
        when (provider) {
            "claude" -> {
                urlStr = "https://api.anthropic.com/v1/messages"
                headers["x-api-key"] = apiKey
                headers["anthropic-version"] = "2023-06-01"
                body = JSONObject().put("model", model).put("max_tokens", 400).put("system", system)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
            }
            "openai" -> {
                urlStr = "https://api.openai.com/v1/chat/completions"
                headers["authorization"] = "Bearer $apiKey"
                body = JSONObject().put("model", model).put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", user)))
            }
            else -> {
                urlStr = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
                headers["x-goog-api-key"] = apiKey
                body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                    .put("contents", JSONArray().put(
                        JSONObject().put("role", "user")
                            .put("parts", JSONArray().put(JSONObject().put("text", user)))
                    ))
            }
        }

        val conn = URL(urlStr).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 5000
            conn.readTimeout = 12000
            conn.doOutput = true
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            if (code == 400 || code == 401 || code == 403 || code == 404) throw IllegalStateException("anahtar/model")
            if (code == 429) { backoffUntil = SystemClock.elapsedRealtime() + 20000; return null }
            if (code != 200) return null
            val json = JSONObject(conn.inputStream.bufferedReader().readText())
            val sb = StringBuilder()
            when (provider) {
                "claude" -> {
                    val arr = json.getJSONArray("content")
                    for (i in 0 until arr.length()) sb.append(arr.getJSONObject(i).optString("text"))
                }
                "openai" -> sb.append(
                    json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
                )
                else -> {
                    val parts = json.getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts")
                    for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                }
            }
            return sb.toString().trim().ifBlank { null }
        } finally {
            conn.disconnect()
        }
    }

    // =================== Gösterim ===================

    private fun readMs(tr: String): Long = (1500L + tr.length * 65L).coerceIn(2500L, 9000L)

    private fun showChunk(c: Chunk) {
        viewChunk = c
        showText(c.tr, c.en, if (live) readMs(c.tr) else readMs(c.tr) * 2)
    }

    private fun status(msg: String) = showText(msg, "", 4000)

    /** Metni gösterir ve okuma süresi bitince kutuyu tamamen gizler (videonun önünü kapatmaz). */
    private fun showText(tr: String, en: String, ms: Long) {
        ui.post {
            val sb = SpannableStringBuilder()
            if (showEn && en.isNotBlank()) {
                val st = sb.length
                sb.append(en)
                sb.setSpan(ForegroundColorSpan(0xFFBBBBBB.toInt()), st, sb.length, 0)
                sb.setSpan(RelativeSizeSpan(0.75f), st, sb.length, 0)
                sb.append("\n")
            }
            sb.append(tr)
            overlay?.text = sb
            overlay?.visibility = View.VISIBLE
            shown = true
            ui.removeCallbacks(hideRunnable)
            if (!paused) ui.postDelayed(hideRunnable, ms)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun addOverlay() {
        overlay = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 17f
            gravity = Gravity.CENTER
            setBackgroundColor(0xB3000000.toInt())
            setPadding(dp(10), dp(6), dp(10), dp(6))
            visibility = View.GONE
        }
        overlayLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(12); y = dp(10) }
        wm.addView(overlay, overlayLp)
    }

    private fun addControls() {
        fun btn(t: String, onClick: () -> Unit) = TextView(this).apply {
            text = t
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { onClick() }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0x99000000.toInt())
            alpha = 0.8f
        }
        val handle = btn("✥") {}
        pauseBtn = btn("⏸") { togglePause() }
        enBtn = btn("EN") { toggleEn() }
        enBtn?.alpha = if (showEn) 1f else 0.45f
        bar.addView(handle)
        bar.addView(btn("⏮") { goPrev() })
        bar.addView(pauseBtn)
        bar.addView(btn("⏭") { goNext() })
        bar.addView(enBtn)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(100); y = dp(10) }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(bar, lp)
                }
            }
            true
        }
        controls = bar
        controlsLp = lp
        wm.addView(bar, lp)
    }

    /** Yatayda kutular ekranın üstünde, dikeyde videonun hemen altında durur (altyazı bölgesinin dışı). */
    private fun placeOverlay(land: Boolean, videoBottom: Int, sw: Int) {
        if (lastLand == land) return
        lastLand = land
        ui.post {
            val lp = overlayLp ?: return@post
            val cl = controlsLp ?: return@post
            if (land) {
                lp.gravity = Gravity.TOP or Gravity.START
                lp.x = dp(12)
                lp.y = dp(10)
                overlay?.maxWidth = (sw - dp(274)).coerceAtLeast(dp(200))
                cl.y = dp(10)
            } else {
                lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                lp.x = 0
                lp.y = videoBottom + dp(56)
                overlay?.maxWidth = sw - dp(24)
                cl.y = videoBottom + dp(8)
            }
            cl.x = (sw - dp(236)).coerceAtLeast(0)
            overlay?.let { wm.updateViewLayout(it, lp) }
            controls?.let { wm.updateViewLayout(it, cl) }
        }
    }

    // =================== Kontroller ===================

    private fun translatedChunks() = chunks.filter { it.tr.isNotBlank() }

    private fun goPrev() {
        val list = translatedChunks()
        if (list.isEmpty()) { status("Henüz geri alınacak çeviri yok"); return }
        live = false
        val cur = viewChunk
        val target = if (!shown || cur == null) list.last() else {
            val i = list.indexOf(cur)
            if (i > 0) list[i - 1] else list.first()
        }
        showChunk(target)
    }

    private fun goNext() {
        val list = translatedChunks()
        if (list.isEmpty()) return
        val i = list.indexOf(viewChunk)
        if (viewChunk == null || i < 0 || i >= list.size - 1) {
            live = true
            showChunk(list.last())
        } else {
            val target = list[i + 1]
            live = target === list.last()
            showChunk(target)
        }
    }

    private fun togglePause() {
        paused = !paused
        pauseBtn?.text = if (paused) "▶" else "⏸"
        if (paused) {
            ui.removeCallbacks(hideRunnable)
            if (!shown) showText("Çeviri duraklatıldı", "", 2000)
        } else {
            assembler.reset()
            live = true
            showText("Çeviri devam ediyor", "", 1500)
        }
    }

    private fun toggleEn() {
        showEn = !showEn
        getSharedPreferences("ceviri", MODE_PRIVATE).edit().putBoolean("showEn", showEn).apply()
        enBtn?.alpha = if (showEn) 1f else 0.45f
        viewChunk?.let { if (shown) showChunk(it) }
    }

    // =================== Servis ===================

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ceviri", "Canlı çeviri", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, "ceviri")
            .setContentTitle("Altyazı çevirisi çalışıyor")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        try { vd?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        projection?.stop()
        recognizer.close()
        translator?.close()
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        controls?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        net.shutdownNow()
        bgThread.quitSafely()
        super.onDestroy()
    }
}

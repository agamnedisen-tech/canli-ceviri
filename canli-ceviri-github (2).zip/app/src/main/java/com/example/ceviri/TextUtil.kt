package com.example.ceviri

/** Çevrilecek bir altyazı parçası. */
class Chunk(var en: String) {
    var tr: String = ""
}

object TextUtil {
    fun norm(w: String): String = w.lowercase().filter { it.isLetterOrDigit() }

    fun lev(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    /** OCR'ın tek harf hatalarını tolere eden kelime eşitliği. */
    fun same(a: String, b: String): Boolean {
        if (a == b) return true
        if (a.length < 5 || b.length < 5) return false
        if (kotlin.math.abs(a.length - b.length) > 1) return false
        return lev(a, b) <= 1
    }
}

/**
 * Ekrandan okunan altyazı metinlerinden YENİ kelimeleri ayıklar ve cümle parçası olarak biriktirir.
 * Kayan (roll-up) altyazılarda aynı kelimeler tekrar tekrar ekranda kalır; her kelime yalnızca bir kez alınır.
 */
class Assembler {
    private val stream = ArrayList<String>()   // şimdiye kadar alınan kelimeler (normalize)
    private val pending = ArrayList<String>()  // çeviri bekleyen kelimeler (orijinal yazım)
    private var lastNewAt = 0L

    fun reset() { stream.clear(); pending.clear() }

    /** Yeni kelime eklendiyse true döner. */
    fun feed(words: List<String>, now: Long): Boolean {
        val orig = words.filter { TextUtil.norm(it).isNotEmpty() }
        if (orig.isEmpty()) return false
        val n = orig.map { TextUtil.norm(it) }
        val start = firstNewIndex(n)
        if (start >= n.size) return false
        for (i in start until n.size) { pending.add(orig[i]); stream.add(n[i]) }
        while (stream.size > 60) stream.removeAt(0)
        lastNewAt = now
        return true
    }

    fun shouldFlush(now: Long): Boolean {
        if (pending.isEmpty()) return false
        val last = pending.last()
        val sentenceEnd = last.endsWith(".") || last.endsWith("?") || last.endsWith("!") || last.endsWith("…")
        return sentenceEnd || pending.size >= 10 || now - lastNewAt >= 1300
    }

    fun take(): String {
        val s = pending.joinToString(" ")
        pending.clear()
        return s
    }

    /** n içinde, daha önce alınmış kelimelerle örtüşen kısmın bittiği yerden sonraki indeks. */
    private fun firstNewIndex(n: List<String>): Int {
        if (stream.isEmpty()) return 0
        val winLen = minOf(stream.size, n.size + 4)
        val s = stream.subList(stream.size - winLen, stream.size)
        val dp = Array(winLen + 1) { IntArray(n.size + 1) }
        for (i in winLen - 1 downTo 0) for (j in n.size - 1 downTo 0) {
            dp[i][j] = if (TextUtil.same(s[i], n[j])) dp[i + 1][j + 1] + 1
            else maxOf(dp[i + 1][j], dp[i][j + 1])
        }
        var i = 0; var j = 0; var m = 0
        var firstJ = -1; var lastJ = -1; var lastI = -1
        while (i < winLen && j < n.size) {
            if (TextUtil.same(s[i], n[j]) && dp[i][j] == dp[i + 1][j + 1] + 1) {
                if (firstJ < 0) firstJ = j
                lastJ = j; lastI = i; m++; i++; j++
            } else if (dp[i + 1][j] >= dp[i][j + 1]) i++ else j++
        }
        val minMatch = if (n.size <= 3) 1 else 2
        val overlap = m >= minMatch && firstJ <= 2 && lastI >= winLen - 2 &&
            m * 10 >= (lastJ - firstJ + 1) * 6
        return if (overlap) lastJ + 1 else 0
    }
}
